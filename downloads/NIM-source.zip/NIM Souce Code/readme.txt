Newton Instant Messenger (Pre-beta 1.0.1)
Copyright (c) 2001-2004 Jake Bordens
Released under the GNU Public License, December 2004

Disclaimer -----------------
quoted from the GPL:
BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

The Back-story -------------------
You probably don't remember me from 'The Newton Underground', a fairly 
popular Newton site from back during the height of the popularity of the 
device.  Credit for the site really goes to Will Nelson, as I really just 
helped out from time to time.

A quick search in google found that the site's last page still exists, 
post February 27, 1996... sad times.  http://www.skyport.com/nelson/newton/

Anyway, back then Mac's sucked... I don't mean to platform war, but I was 
a PC user, and much of my development back then was on the Windows 
version of the NTK.  I actually recently came across some of this old 
code, including NUGDrop (a backdrop application with tabs at the bottom 
for access to the drawer.)

Then during the 8 months or so between college and employment, I got 
bored, and found myself hanging out in #Newton on IRC.  I decided to take 
up this project, Newton Instant messenger.  As always, the Mac 
development environment was more developed, and so I chose to use 
BasiliskII to develop.  This only reinforced my opinion that, back then, 
Macs really sucked.

I became employed and left Pittsburgh, packing up all my stuff.  The my 
code got packed away.... never to be found again.  Until now...  During 
an effort to migrate all my old Syquest cartridges and Zip disks to DVD, 
I found the source code on a lone CDROM.  Took some effort to get it into 
a usable state, as it was saved to a PC drive through BasiliskII, meaning 
that the resource fork was messed up.  After getting BasiliskII running 
again, copying to a HFS drive image, all seems well.

I've decided to release the code under GPL.  I had originally hoped to 
find someone seriously interested in maintaining it.  No one stepped up, 
and hence the code was banished to a box in my basement until now.  
Better it see the light of day rather than stay there, I figure.

The code ----------------
I make no warranties on this code.  For all I know the Jabber protocol 
has changed 800 times and this no longer works.  The only bug I can 
recall hearing about in NIM is that certain characters don't print right, 
making multi-language chats difficult.  I'm sure there's got to be more 
wrong with it than just that.

Even so, the code is probably poorly written, poorly constructed, poorly 
commented, poorly formatted, and obviously poorly maintained.  I 
apologize for that, but thats just the way it is.  

I have finally, after all these years, gotten over the grudge I held 
against Apple for killing the Newton.  I am now happy to report that with 
Mac OS X 10.3, Apple seems to be getting things right.  Too bad they're 
focusing too much on those silly iPods... I guess they're selling well 
enough.  Hopefully Steve's not putting all his eggs in one basket.

I've gotten the Newton Development Tools running under classic on my 
Powerbook.  I added a few comment headers indicating that NewtonIM is 
GPLed and asked it to build a package.  It seems to build so I consider 
it good enough to release.

On architecture, I only have this commend from my website:

NewtonIM connects to the jabber server and authenticates using plain text 
authentication. Then, the stream of XML tags coming from the sever is 
tokenized and inserted into an array. This array is the XML fifo which 
the parser reads, one at a time in the base view's viewIdleScript.


Contacting me --------
You can reach me at jake@allaboutjake.com.  

I do try to answer from time to time.  I do suggest you not ask questions 
like "what were you thinking when you coded things this way" as I have 
thoroughly forgotten.

On and in case you're wondering, I still have my Newton MP2100 
(upgraded).  I can't bring myself to sell it, though I don't really use 
it.  It's still a better device than any Pocket PC available today, in my 
opinion.  However, most of my needs are met by my Danger Hiptop 2.

Take care,
Jake

